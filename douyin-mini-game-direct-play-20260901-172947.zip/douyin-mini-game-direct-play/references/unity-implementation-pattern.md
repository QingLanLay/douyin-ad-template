# Unity 实现模式

## 推荐组件边界

```text
AdManager/TTSDKBootstrap
  - 唯一 TT.InitSDK 所有者
  - 广告、分享、加桌、侧边栏、登录

DouyinDirectPlayManager (DontDestroyOnLoad)
  - 等待 SDK 初始化
  - 读取 LaunchOption 和路由
  - 管理状态机、ReportScene、Feed 监听
  - 以全场景订阅为主链，分开记录订阅尝试、三场景默认就绪写入和复访入口加载

GameEntryService / BootLoader
  - 普通与直玩入口分流、场景加载

LevelMgr
  - 目标关卡资源加载
  - 支持是否计时/保存及 onReady
```

## 状态机

```csharp
public enum DirectPlayPhase
{
    None,
    HiddenPreloading,
    CardVisiblePreview,
    CardHiddenPreview,
    FullGameEntered,
    ReturnedToFeed,
    ConvertedToNormalGame
}
```

不要只靠这个枚举推断所有状态；至少另存 `isCardVisible`、`isInFullGame`、`hasEnteredFullGame` 三个幂等标记。首次直玩 `OnShow` 是 `HiddenPreloading -> CardVisiblePreview`；`OnHide` 在卡片态切为 `CardHiddenPreview`。`FeedEnter` 是进入 `FullGameEntered`，`FeedExit` 是返回推荐流；返回后根据新的 OnShow/OnHide 决定卡片是否恢复。获客试玩完成并转正式流程后切换为 `ConvertedToNormalGame`。

## 入口配置模型

```csharp
public enum DirectPlayCompleteAction
{
    ContinueNextLevel,
    StartNormalGameFromLevel1,
    ReturnToSavedLevel,
    EnterMainMenu
}

[Serializable]
public sealed class DirectPlayEntry
{
    public string contentId;
    public string routeKey;
    public int previewLevel = 1;
    public bool commitPreviewProgress;
    public DirectPlayCompleteAction completeAction;
    public int normalStartLevel = 1;
}
```

解析顺序：`TryResolveByExtraRoute()`、`TryResolveByContentId()`、`UseSafeDefault()`。

## 启动参数模板

```csharp
LaunchOption option = TT.GetLaunchOptionsSync();
string scene = option?.Scene ?? string.Empty;
bool direct = scene.EndsWith("3041", StringComparison.Ordinal);

if (direct && option.Query != null)
{
    option.Query.TryGetValue("feed_game_channel", out string channelText);
    option.Query.TryGetValue("feed_game_scene", out string sceneText);
    option.Query.TryGetValue("feed_game_content_id", out string contentId);
    option.Query.TryGetValue("feed_game_extra", out string extra);
}
```

所有失败均回退普通启动或安全默认入口。

## 关卡加载适配

将 `InitLevel(int level)` 扩展为等价接口：

```csharp
InitLevel(int level, bool startCountdown, bool saveProgress, Action onReady)
```

直玩预加载：

```csharp
InitLevel(targetLevel, false, false, OnLevelAssetsReady);
```

资源准备后等待 `WaitForEndOfFrame` 再 `NotifyGameplayReady()`。隐藏预加载保持 AI、音频、字幕和试玩计时暂停；首次直玩 OnShow 后启动卡片体验。首次 FeedEnter 后才提交会话/存档、注册登录、真实 active 和完整游戏承接。

## ReportScene 模式

```csharp
private bool _reported;

void NotifyGameplayReady()
{
    if (!IsDirectPlay || _reported) return;
    _reported = true;

    var p = new JsonData();
    p["sceneId"] = 7001;
    p["costTime"] = Mathf.RoundToInt(Time.realtimeSinceStartup * 1000f);
    TT.ReportScene(p, OnSuccess, OnFailed, RegisterFeedListener);
}
```

如需精确起点，在最早的 RuntimeInitializeOnLoadMethod 记录时间；不要固定 3000ms。

## Feed 监听模式

```csharp
private OnFeedStatusChangeCallback _callback;
_callback = result =>
{
    if (result.Type == FeedStatusEnum.FeedEnter) HandleEnter();
    if (result.Type == FeedStatusEnum.FeedExit) HandleExit();
};
TT.OnFeedStatusChange(_callback);
```

销毁时用同一个委托调用 `TT.OffFeedStatusChange(_callback)`。优先调用项目自己的暂停系统，避免覆盖广告/菜单暂停。

## 卡片可见监听模式

订阅 `TT.GetAppLifeCycle().OnShow`/`OnHide`，但先用推荐流启动上下文和 `isInFullGame` 做门控：

```csharp
void HandleAppShow(Dictionary<string, object> args)
{
    if (!isDirectPlay || isInFullGame || isCardVisible) return;
    isCardVisible = true;
    StartOrResumeCardPreview();
}

void HandleAppHide()
{
    if (!isDirectPlay || isInFullGame || !isCardVisible) return;
    isCardVisible = false;
    PauseCardPreview();
}
```

具体 `OnHide` 委托签名以项目当前 TTSDK 为准。Feed 事件只处理完整游戏进出：`FeedEnter` 设置 `isInFullGame=true` 并执行真实进入业务，不能代替 `StartOrResumeCardPreview()`；`FeedExit` 设置 `isInFullGame=false` 并暂停完整游戏，等待可见性事件再恢复卡片。

## 复访闭环

复访接入至少保留三个状态：`subscriptionAttemptedThisLaunch`、`returnReadinessRefreshInProgress/reported`、当前 `FeedLaunchContext`。全场景订阅是主链：查询确认已订阅，或本次已经发起 `RequestFeedSubscribe(type=play, allScene=true)` 后，立即批量写入 Scene 1/2/3 的 `Status=1`。不要等待离线收益、体力恢复或重要事件等业务条件；`GetFeedData` 只用于排障，不作为路由或加载前置条件。详细参数见 [全场景订阅与复访默认就绪](revisit-subscription-readiness.md)。

复访启动路由应优先使用平台本次真实下发的 Scene 1/2/3；只有启动参数缺失或越界时才回退配置中的场景。ContentID 必须先做 `channel=1 + exact content_id` 精确匹配，未知 ID 才进入明确记录日志的安全兜底，不能静默伪装成目标复访内容。

## 迁移检查

创建新管理器前搜索并移除旧 `HandleLaunchScene()`、`ReportLaunchScene()`、匿名 Feed 监听，防止重复上报和监听。

## 编辑器模拟

提供 `simulateDirectPlay`、`simulateContentId`、`simulateExtra`、`simulateChannel=2`、`simulateScene=0`，生产包默认关闭。调试器必须分别提供“模拟 OnShow”“模拟 OnHide”“模拟 FeedEnter”“模拟 FeedExit”，按钮文案不得把 FeedEnter 写成卡片曝光。至少测试两个入口和未知入口。
