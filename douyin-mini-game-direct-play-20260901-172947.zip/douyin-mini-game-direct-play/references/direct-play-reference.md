# 抖音小游戏推荐流直玩参考

> 使用前重新核对官方文档。字段、版本和后台入口可能变化，只信任 `developer.open-douyin.com`。

## 官方入口

- 获客版：`https://developer.open-douyin.com/docs/resource/zh-CN/mini-game/develop/guide/open-ability/feed/customer-access-guide`
- 设计规范：`https://developer.open-douyin.com/docs/resource/zh-CN/mini-game/develop/guide/open-ability/feed/feed-game-design-guide`
- 复访版：`https://developer.open-douyin.com/docs/resource/zh-CN/mini-game/develop/guide/open-ability/feed/minigame-feedpush-setting-guide`
- 直玩 API：`https://developer.open-douyin.com/docs/resource/zh-CN/mini-game/develop/api/c-api/tt-feed-game-api`
- FAQ：`https://developer.open-douyin.com/docs/resource/zh-CN/mini-game/develop/server/feed-game/feed-game-faq`

## 核心心智模型

平台会在用户真实进入前创建隐藏小游戏容器并预启动游戏。游戏不是常驻后台等待事件；只有平台启动 Unity 后，游戏代码才会执行并读取启动上下文。

- **隐藏预启动**：Unity 已运行，可加载场景并 ReportScene；卡片还不可见，用户可能从未看到。
- **划到卡片**：直玩上下文中的 `TT.GetAppLifeCycle().OnShow`，卡片开始可见；此时才开始卡片 AI、动画、配音、字幕和试玩计时。
- **划走卡片**：对应 `OnHide`，暂停卡片内玩法、音频、字幕与计时；之后再次 `OnShow` 才恢复。
- **进入完整小游戏**：`FeedEnter`，官方定义为“从推荐流进入小游戏”，对应用户点击进入，不是划到卡片。
- **退出完整小游戏**：`FeedExit`，官方定义为“退出小游戏回到推荐流”，不是普通划走卡片。

不要用一条枚举同时代替两组信号：

```text
卡片可见性：HiddenPreload -> OnShow -> CardVisible -> OnHide -> CardHidden
完整游戏进出：CardPreview -> FeedEnter -> FullGame -> FeedExit -> RecommendationFeed
```

`OnShow`/`OnHide` 是 App 生命周期信号，普通启动和前后台切换也可能触发。只有启动参数已确认推荐流直玩、且当前尚未处于完整游戏时，才能把它解释为卡片可见/不可见；业务处理必须幂等。

## 获客启动字段

```text
scene                  以 3041 结尾
feed_game_channel      2 表示获客
feed_game_scene        0 表示获客场景
feed_game_content_id   平台内容/文案 ID
feed_game_extra        开发者自定义透传字段
```

所有字段按可空、不可信输入处理。使用 `EndsWith("3041")`，不要使用模糊包含判断。

## 获客版最小 API

```csharp
TT.GetLaunchOptionsSync();
TT.ReportScene(param, success, failed, complete);
TT.OnFeedStatusChange(callback);
TT.OffFeedStatusChange(callback);
```

`ReportScene`：

```json
{"sceneId":7001,"costTime":"真实启动到核心玩法就绪的毫秒耗时"}
```

不要写死耗时。不要在 SDK 初始化完成时立即上报；等待目标关卡资源、UI、输入和首个可玩帧准备完成。

## 获客版与复访版边界

`feed_game_channel=2` 是获客，`feed_game_channel=1` 是复访。获客版无需强行调用 `StoreFeedData`、`GetFeedData`、`CheckFeedSubscribeStatus`、`RequestFeedSubscribe`。复访场景通常为 1 离线收益、2 体力恢复、3 重要事件；获客入口场景 0 不用于复访订阅。

复访版内部还要继续拆成三条独立能力：

1. `CheckFeedSubscribeStatus`/`RequestFeedSubscribe`：用户是否授权推荐流提醒；全场景请求使用 `type=play, allScene=true`。
2. `StoreFeedData`/`GetFeedData`：写入或查询某个 Scene + ContentID 的复访状态。采用全场景订阅主流程时，可以在申请后直接把 Scene 1/2/3 写为默认就绪，无需等待各场景业务条件；`GetFeedData` 仅作可选排障。
3. `feed_game_channel=1`、`feed_game_scene=1/2/3`、`feed_game_content_id`：平台真正启动复访后，项目加载哪个内容。

订阅接口不会自动代替项目调用 `StoreFeedData`，`OnFeedStatusChange` 也不承担前两项职责。当前默认工作流以全场景申请为主链：确认已订阅或发起申请后，项目立即批量写入三场景 `Status=1`；不以 `GetFeedData` 回读阻塞复访加载。

两者共用 OnShow/OnHide 与 FeedEnter/FeedExit 的事件含义：

- 获客卡片 `OnShow` 后播放试玩；首次 `FeedEnter` 再做注册、真实 active 和正式流程承接。
- 复访卡片 `OnShow` 后展示对应复访内容；首次 `FeedEnter` 再承接完整游戏状态。
- `StoreFeedData`/`GetFeedData` 负责复访内容数据，不代表卡片已展示，也不代表用户已点击进入。

## 多入口

多个获客入口的 `feed_game_scene` 可能全部为 0。使用：

```text
feed_game_extra.route > feed_game_content_id 映射 > 默认入口
```

建议 extra：

```json
{"route":"acquisition_level_20","version":1}
```

只接受本地白名单 route，不直接信任任意 level。无法配置 extra 时，使用 content_id 映射；运营频繁变化时可使用远程配置并保留本地兜底。

## 预加载阶段

避免：强制登录/注册/创角、真实 active、保存正式进度、扣体力、正式奖励、倒计时、AI/剧情推进、配音/字幕播放、签到/加桌/侧边栏/订阅/插屏、大量服务端请求。

允许：初始化 Unity/SDK、加载目标场景和关卡资源、构建 UI/输入/可玩画面、ReportScene、注册 Feed 状态监听。

## 四个事件的职责表

| 信号 | 用户动作/平台位置 | 应做 | 不应做 |
|---|---|---|---|
| `OnShow` | 划到直玩卡片，卡片可见 | 开始/恢复卡片 AI、动画、音频、字幕、试玩计时 | 注册创角、把用户算作已进入完整游戏 |
| `OnHide` | 卡片划走或容器不可见 | 暂停卡片体验并保存内存态播放位置 | 当作 `FeedExit`、清空试玩进度 |
| `FeedEnter` | 点击卡片进入完整小游戏 | 首次真实进入、静默注册/登录、active、完整游戏承接 | 当作卡片首次曝光、从头重播卡片配音 |
| `FeedExit` | 退出完整小游戏回推荐流 | 暂停完整游戏；等待可见性信号决定卡片恢复 | 当作普通卡片划走、立即无条件恢复卡片 |

官方获客指南还提示：不支持 Feed 进入事件的低版本可用“用户首次触摸”兼容真实进入判断。这个兜底只替代 `FeedEnter` 的真实进入判断，不替代 `OnShow` 的卡片可见判断。

## 版本检查

不要把历史版本要求写死为永久事实。读取项目 TTSDK `package.json`，再核对当前官方最低版本、客户端版本和基础库版本。
