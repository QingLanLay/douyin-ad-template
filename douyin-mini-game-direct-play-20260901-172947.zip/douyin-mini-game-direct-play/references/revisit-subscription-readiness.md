# 全场景订阅与复访默认就绪

用于复访版推荐流直玩。使用前重新核对抖音开放平台当前复访指南和项目实际 TTSDK 签名。

## 以全场景订阅为主链

```text
订阅授权
  CheckFeedSubscribeStatus
    -> 已订阅 ---------------------+
    -> 未订阅 -> RequestFeedSubscribe(type=play, allScene=true)
                                      |
                                      v
默认就绪写入                     RefreshReturnSceneReadyData
  Scene 1/2/3 -> StoreFeedData(Status=1)
                                      |
                                      v
复访启动
  channel=1 + scene=1/2/3 + content_id -> 精确路由 -> 加载 -> ReportScene -> OnShow
```

这些 API 职责不同，但当前默认工作流由订阅申请串起：

- `CheckFeedSubscribeStatus` 确认已订阅，或代码已经发起一次 `RequestFeedSubscribe` 后，立即触发三场景默认就绪写入。
- Scene 1/2/3 不再判断离线收益、体力恢复或重要事件是否真实满足；统一写入 `Status=1`。
- `StoreFeedData` 仍须由项目明确调用；全场景订阅接口不会自动代替这三次写入。
- `GetFeedData` 是可选排障查询，不是业务放行、复访路由或内容加载的前置条件。
- `OnFeedStatusChange` 只监听 FeedEnter/FeedExit，与订阅和就绪数据无关。

## 全场景订阅

查询和请求使用同一套全场景参数：

```json
{"type":"play","allScene":true}
```

全场景模式不要同时传单独 `scene` 或 `contentIDs`。每次游戏启动最多尝试拉起一次订阅弹窗；由普通游戏正式胜利或失败结算等真实玩家手势触发。隐藏预加载、AI 卡片试玩和教学结算不能设置“本次已尝试”，否则正式结算将失去机会。

订阅状态回包要记录完整原始 JSON，再兼容解析 `subscribed`、`status`、`success`。值可能是 bool、数字 0/1 或字符串；无法识别时保留 unknown，不要把未知回包直接当作未订阅而反复弹窗。注意：这里解析的是“订阅状态”，不是后文 `GetFeedData` 的场景就绪 `status`。

以下路径都进入 `RefreshReturnSceneReadyData()`：

1. 查询确认已经订阅；
2. 本次发起全场景订阅申请。申请回调成功或失败仍分别记录，但场景默认就绪写入不等待业务条件，也不依赖查询回包字段决定是否执行。

查询/请求失败应记录 code、message 和原始回包，遵守一次尝试门闩，避免结算重复弹窗。订阅结果日志和三场景 Store 结果日志分开记录。

## Scene 1/2/3 申请后直接默认就绪

从复访配置收集 ContentID：远程成功时以远程配置为准，网络/JSON 失败才回退本地。只接受 `channel=1`、非空且非占位符的 ContentID、Scene 1~3。

每个 Scene 优先使用显式配置的 ContentID。业务允许三个默认场景共享内容时，缺少独立 ID 的场景可以复用首个有效复访 ID，但日志必须写明实际 Scene + ContentID；平台要求独立 ID 时必须逐场景配置，不能复用。

不检查各场景的真实业务状态。全场景订阅申请路径触发后，直接按当前 SDK 类型写入：

```text
Scene      = 1 / 2 / 3
Status     = 1
ContentID  = 该场景实际使用的复访 ContentID
LeftValue  = "timeStampMs"
Operator   = ">="
RightValue = 当前 UTC Unix 毫秒时间戳字符串
```

使用 `refreshInProgress` 防并发，使用 `reportedThisSession` 防同一运行重复批量写入。逐场景记录 Store 成功/失败；失败只进入日志和有限排障，不应重新拉起订阅，也不应阻止项目按平台真实启动参数加载复访场景。

## GetFeedData 仅用于排障

官方复访指南把 `getFeedData` 标为可选查询。本 Skill 不把它设为业务必做：默认流程只要发起全场景订阅申请，就批量写入 Scene 1/2/3 的 `Status=1`，随后可正常等待平台复访启动并加载对应场景。

只有平台提示“不存在相关就绪数据”、用户明确要求核验，或需要定位后台绑定问题时，才对相同 Scene + ContentID 调用 `GetFeedData`。至少记录：Scene、ContentID、返回 `status`、原始回包、失败 code/message。

排障时可以回读：

```text
Scene 1 + 实际 ContentID -> status=1
Scene 2 + 实际 ContentID -> status=1
Scene 3 + 实际 ContentID -> status=1
```

缺少回读或返回非 1 不阻塞订阅申请、复访路由和场景加载；它只说明平台侧数据需要继续排查。先核对三次 Store 的 Scene、ContentID、时间戳和原始回包，不要重复修改全场景订阅或 `OnFeedStatusChange`。

## 复访启动与内容加载

平台实际启动后读取：

```text
feed_game_channel=1
feed_game_scene=1/2/3
feed_game_content_id=<本次复访内容>
```

按 `channel=1 + exact content_id` 解析远程/本地配置。平台启动参数给出的 Scene 在 1~3 时优先使用真实 Scene；只有缺失或越界时才回退配置场景。之后加载对应复访内容，完成可玩画面和 `ReportScene(7001)`，并等 `OnShow` 才开始 AI、配音、字幕和计时。

未知 ContentID 可以进入明确记录的安全兜底，但不能把兜底成功说成目标复访入口已正确匹配。

## 常见失败顺序

出现“已订阅，但不存在相关就绪数据”时依次检查：

1. 测试包是否晚于最新源码、配置和 Store/Get 修复；核对构建时间与哈希，旧包复测不会变化。
2. 是否确实走全场景参数，而不是单场景参数。
3. 订阅查询原始回包是否因只读一个字段而误判；兼容 `subscribed/status/success`。
4. Scene 1/2/3 是否各自执行 Store，实际 ContentID 是否为空、占位符、渠道错误或与后台不一致。
5. 时间戳单位、LeftValue、Operator、RightValue 和 SDK 初始化/登录时机是否正确。
6. 需要排障时，是否对相同 Scene + ContentID 执行 Get 并记录原始回包；不要把回读作为路由放行条件。
7. 平台复访启动参数是否实际下发 `channel=1`、目标 Scene 和 ContentID；项目是否不依赖 Get 结果而精确路由并加载相应内容。

`10401` 等内部错误不能直接归因于视频 URL 或订阅失败。应记录逐 ID/逐 Scene 回包，并检查应用资格、后台绑定、登录时机和平台状态。
