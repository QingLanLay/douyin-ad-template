# 直玩接入审查清单

## SDK 与唯一所有者
- [ ] 找到 TTSDK 版本和官方最低版本。
- [ ] 仅有一个 `TT.InitSDK`、启动参数解析器和 Feed 监听所有者。

## 启动路由
- [ ] `scene` 使用后缀 3041 判断且可空。
- [ ] Query 全部安全读取。
- [ ] 普通启动保持原流程；获客绕过开始、登录和选关页。
- [ ] 未知入口有默认路由。

## 多入口
- [ ] 不用 `feed_game_scene=0` 区分第 10/20/30 关。
- [ ] 优先白名单 `extra.route`；content_id 映射可配置。
- [ ] 每个入口明确通关策略，高等级体验不覆盖老存档。

## 生命周期边界
- [ ] 隐藏预加载不播放配音/字幕，不启动试玩计时或 AI，不保存、扣体力、发正式奖励、强制登录或弹窗。
- [ ] 首次直玩 OnShow 才启动卡片体验；OnHide/OnShow 可重复暂停恢复且保留正确播放进度。
- [ ] SchemePrepared、资源加载完成、VideoPlayer.prepareCompleted、Ready、ReportScene 及其回调只标记就绪，没有直接开始有声播放或字幕时间轴。
- [ ] 配音和首条字幕由同一个 OnShow 后启动方法同帧放行，不存在两套起点或字幕先于配音开始。
- [ ] FeedEnter 明确表示点击进入完整小游戏，不被用于判断“划到卡片”或启动卡片配音。
- [ ] FeedExit 明确表示退出完整小游戏回推荐流，不被用于判断普通“划走卡片”。
- [ ] 首次 FeedEnter 才执行静默注册/登录、真实 active 和完整游戏承接，且不会从头重播卡片内容。
- [ ] FeedExit 后等待实际 OnShow/OnHide 状态决定是否恢复卡片，不无条件播放。
- [ ] `isCardVisible`、`isInFullGame`、`hasEnteredFullGame` 分开保存，回调重复或紧邻到达时保持幂等。

## 获客与复访
- [ ] `feed_game_channel=2` 按获客处理，`feed_game_channel=1` 按复访处理。
- [ ] 获客 scene 0 与复访 scene 1/2/3 的路由和承接策略分开。
- [ ] StoreFeedData/GetFeedData 只负责复访数据，不被当作可见性或进入信号。

## 复访订阅与就绪闭环
- [ ] 全场景订阅使用 `type=play, allScene=true`，不同时传单独 scene/contentIDs。
- [ ] 订阅状态兼容读取 `subscribed/status/success`，兼容 bool、0/1 和字符串形式，并记录原始回包。
- [ ] 每次游戏启动最多拉起一次订阅；普通游戏正式胜利与失败结算可触发，AI 试玩、隐藏预加载和教学结算不消耗机会。
- [ ] 全场景订阅是主链；已订阅或本次已经发起申请后都会立即刷新复访默认就绪数据。
- [ ] 远程配置优先、本地配置兜底；过滤非复访渠道、空 ID、占位 ID 和 Scene 非 1~3 的项。
- [ ] Scene 1/2/3 均调用 StoreFeedData；每个场景优先使用独立 ContentID，缺失时才按明确策略复用有效复访 ID。
- [ ] 三个场景统一直接写入 `Status=1`，不检查离线收益、体力是否恢复或重要事件是否发生。
- [ ] StoreFeedData 使用 `Status=1`，时间戳单位与左右值/操作符符合当前官方接口和目标 SDK 签名。
- [ ] GetFeedData 只用于平台排障或明确要求的验收，不作为业务放行、复访路由或场景加载的前置条件。
- [ ] `OnFeedStatusChange` 只负责 FeedEnter/FeedExit，没有被用于订阅或就绪判断。
- [ ] 复访启动时优先使用平台真实下发的 Scene 1/2/3，并按 `channel=1 + exact content_id` 加载对应内容。
- [ ] 新源码已重新构建；测试包时间/哈希晚于订阅、三场景 Store 和路由修复，未继续拿旧包做无效复测。

## 场景就绪
- [ ] `sceneId=7001`，costTime 真实。
- [ ] 资源、UI、输入准备且渲染后上报。
- [ ] 每次启动最多一次。

## 清理与兼容
- [ ] 保存监听委托并 OffFeedStatusChange。
- [ ] 无新旧管理器重复调用。
- [ ] 暂停不破坏广告/菜单状态。
- [ ] 编辑器调试器分别模拟 OnShow、OnHide、FeedEnter、FeedExit，按钮和日志不混用术语。
- [ ] 普通、多个获客、复访、未知入口编译运行通过。
- [ ] 完成平台离线测试、审核和风险检测。
