﻿param(
    [Parameter(Mandatory = $false)]
    [string]$ProjectPath = (Get-Location).Path
)

$ErrorActionPreference = 'Stop'
$resolved = (Resolve-Path -LiteralPath $ProjectPath).Path
Write-Host "=== 抖音小游戏直玩审计 ===" -ForegroundColor Cyan
Write-Host "项目: $resolved"

$assets = Join-Path $resolved 'Assets'
$packages = Join-Path $resolved 'Packages'
if (-not (Test-Path -LiteralPath $assets)) { throw "未找到 Assets 目录: $resolved" }

Write-Host "`n[1] TTSDK 版本" -ForegroundColor Yellow
$sdkPackages = Get-ChildItem -LiteralPath $assets -Recurse -File -Filter package.json -ErrorAction SilentlyContinue |
    Where-Object { $_.FullName -match 'bytedance|starksdk|ttsdk' }
if (-not $sdkPackages) { Write-Host '未找到 TTSDK package.json' -ForegroundColor DarkYellow }
foreach ($file in $sdkPackages) {
    try {
        $json = Get-Content -LiteralPath $file.FullName -Raw -Encoding utf8 | ConvertFrom-Json
        Write-Host ("{0}  version={1}" -f $file.FullName, $json.version)
    } catch { Write-Host $file.FullName }
}

$sourceRoots = @($assets)
if (Test-Path -LiteralPath $packages) { $sourceRoots += $packages }
$csFiles = foreach ($sourceRoot in $sourceRoots) {
    Get-ChildItem -LiteralPath $sourceRoot -Recurse -File -Filter *.cs -ErrorAction SilentlyContinue |
        Where-Object { $_.FullName -notmatch '\\Assets\\Plugins\\ByteGame\\' }
}
$directPlayFiles = @($csFiles | Where-Object { $_.FullName -match 'Feed|DirectPlay|推荐流' })

Write-Host "`n[2] 核心 API" -ForegroundColor Yellow
$patterns = @('TT\.InitSDK','GetLaunchOptionsSync','ReportScene\s*\(','GetAppLifeCycle','\.OnShow\s*\+=','\.OnHide\s*\+=','OnFeedStatusChange','OffFeedStatusChange','FeedEnter','FeedExit','StoreFeedData','GetFeedData','CheckFeedSubscribeStatus','RequestFeedSubscribe','allScene','subscribed','status','success','feed_game_content_id','feed_game_extra','feed_game_channel','feed_game_scene')
foreach ($pattern in $patterns) {
    $hits = $csFiles | Select-String -Pattern $pattern -CaseSensitive:$false
    Write-Host ("`n-- {0}: {1} --" -f $pattern, @($hits).Count)
    $hits | Select-Object -First 20 | ForEach-Object { Write-Host ("{0}:{1}: {2}" -f $_.Path, $_.LineNumber, $_.Line.Trim()) }
}

Write-Host "`n[3] 启动、关卡和用户时机" -ForegroundColor Yellow
$flowPatterns = @('class\s+.*Boot','LoadSceneAsync','InitLevel\s*\(','StartCountdown','Save\s*\(','DeductStamina','ReportActive\s*\(','TT\.Login')
foreach ($pattern in $flowPatterns) {
    $hits = $csFiles | Select-String -Pattern $pattern -CaseSensitive:$false
    if ($hits) {
        Write-Host ("`n-- {0} --" -f $pattern)
        $hits | Select-Object -First 12 | ForEach-Object { Write-Host ("{0}:{1}: {2}" -f $_.Path, $_.LineNumber, $_.Line.Trim()) }
    }
}

Write-Host "`n[4] 构建场景" -ForegroundColor Yellow
$buildSettings = Join-Path $resolved 'ProjectSettings\EditorBuildSettings.asset'
if (Test-Path -LiteralPath $buildSettings) {
    Select-String -LiteralPath $buildSettings -Pattern 'path:' | ForEach-Object { Write-Host $_.Line.Trim() }
}

Write-Host "`n[5] 风险" -ForegroundColor Yellow
$initCount = @($csFiles | Select-String -Pattern '^\s*TT\.InitSDK\s*\(' -CaseSensitive:$false).Count
$feedOnCount = @($csFiles | Select-String -Pattern '^\s*TT\.OnFeedStatusChange\s*\(' -CaseSensitive:$false).Count
$feedOffCount = @($csFiles | Select-String -Pattern '^\s*TT\.OffFeedStatusChange\s*\(' -CaseSensitive:$false).Count
$appShowCount = @($csFiles | Select-String -Pattern '\.OnShow\s*\+=' -CaseSensitive:$false).Count
$appHideCount = @($csFiles | Select-String -Pattern '\.OnHide\s*\+=' -CaseSensitive:$false).Count
$directPlayShowCount = @($directPlayFiles | Select-String -Pattern '\.OnShow\s*\+=' -CaseSensitive:$false).Count
$directPlayHideCount = @($directPlayFiles | Select-String -Pattern '\.OnHide\s*\+=' -CaseSensitive:$false).Count
$cardPlaybackCount = @($directPlayFiles | Select-String -Pattern 'AudioSource|VideoPlayer|Voice|Voiceover|Subtitle|Caption|Cue|配音|字幕|\.Play\s*\(' -CaseSensitive:$false).Count
$subscribeRequestCount = @($csFiles | Select-String -Pattern 'TT\.RequestFeedSubscribe\s*\(' -CaseSensitive:$false).Count
$allSceneCount = @($csFiles | Select-String -Pattern 'allScene' -CaseSensitive:$false).Count
$storeFeedDataCount = @($csFiles | Select-String -Pattern 'TT\.StoreFeedData\s*\(' -CaseSensitive:$false).Count
$getFeedDataCount = @($csFiles | Select-String -Pattern 'TT\.GetFeedData\s*\(' -CaseSensitive:$false).Count
if ($initCount -gt 1) { Write-Warning "发现 $initCount 处 TT.InitSDK，请确认唯一所有者。" }
if ($feedOnCount -gt 0 -and $feedOffCount -eq 0) { Write-Warning '存在 OnFeedStatusChange，但未发现 OffFeedStatusChange。' }
if ($feedOnCount -gt 1) { Write-Warning "发现 $feedOnCount 处 OnFeedStatusChange，请排查重复监听。" }
if ($directPlayShowCount -gt 0 -and $directPlayHideCount -eq 0) { Write-Warning '推荐流代码存在 OnShow，但未发现 OnHide。卡片划走后可能仍继续 AI、配音、字幕或计时。' }
if ($directPlayHideCount -gt 0 -and $directPlayShowCount -eq 0) { Write-Warning '推荐流代码存在 OnHide，但未发现 OnShow。卡片再次可见后可能无法恢复体验。' }
if ($feedOnCount -gt 0 -and $directPlayShowCount -eq 0) { Write-Warning '发现 Feed 进入/退出监听，但推荐流代码中未发现 OnShow。请确认没有把 FeedEnter 误当成划到卡片。' }
if ($cardPlaybackCount -gt 0 -and ($directPlayShowCount -eq 0 -or $directPlayHideCount -eq 0)) {
    Write-Warning '发现疑似卡片自动试玩/配音/字幕代码，但 OnShow/OnHide 监听不完整。请确认没有把 FeedEnter/FeedExit 误当成划到/划走卡片。'
}
if ($subscribeRequestCount -gt 0 -and $allSceneCount -eq 0) { Write-Warning '发现 RequestFeedSubscribe，但未发现 allScene。请确认需要的是全场景订阅而不是单场景订阅。' }
if ($subscribeRequestCount -gt 0 -and $storeFeedDataCount -eq 0) { Write-Warning '发现推荐流订阅，但未发现 StoreFeedData。订阅成功不代表 Scene 1/2/3 已就绪。' }
if ($storeFeedDataCount -gt 0 -and $getFeedDataCount -eq 0) { Write-Host 'INFO: 发现 StoreFeedData，未发现 GetFeedData。默认就绪流程允许不回读；平台报错时再增加 GetFeedData 排障。' -ForegroundColor DarkGray }

Write-Host "`n生命周期计数(全项目): OnShow=$appShowCount, OnHide=$appHideCount, OnFeedStatusChange=$feedOnCount, OffFeedStatusChange=$feedOffCount"
Write-Host "生命周期计数(推荐流范围): OnShow=$directPlayShowCount, OnHide=$directPlayHideCount, 疑似播放/字幕命中=$cardPlaybackCount"
Write-Host "复访能力计数: RequestFeedSubscribe=$subscribeRequestCount, allScene=$allSceneCount, StoreFeedData=$storeFeedDataCount, GetFeedData=$getFeedDataCount"
Write-Host '术语边界: OnShow/OnHide=卡片可见性；FeedEnter/FeedExit=进入/退出完整小游戏。' -ForegroundColor Cyan
Write-Host "`n审计完成。结合 references/review-checklist.md 人工确认生命周期。" -ForegroundColor Green
