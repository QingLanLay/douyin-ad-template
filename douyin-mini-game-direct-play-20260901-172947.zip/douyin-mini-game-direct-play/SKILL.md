---
name: douyin-mini-game-direct-play
description: 为 Unity 或团结引擎抖音小游戏设计、接入、迁移和审查推荐流直玩能力，覆盖获客版与复访版、卡片 OnShow/OnHide 与 FeedEnter/FeedExit 的生命周期边界、TTSDK 启动参数/场景就绪、平台后台预启动、多入口 content_id/extra 路由、进度继承、普通启动分流、现有 AdManager 解耦、平台配置与验收。用于用户提出“接入抖音直玩/推荐流直玩/获客入口/复访入口/多个直玩关卡/3041/ReportScene/OnFeedStatusChange/StoreFeedData”，或需要检查现有 Unity 项目是否正确接入直玩时。
---

# 抖音小游戏推荐流直玩

## 工作原则

- 先检查项目，再设计或修改；不要凭模板覆盖现有启动、关卡、存档和 SDK 初始化流程。
- 涉及抖音最新规则、客户端版本、基础库版本或后台字段时，只使用抖音开放平台官方文档并重新联网核对。
- 区分“已有 API 调用代码”和“完整业务接入”。出现 `TT.GetLaunchOptionsSync` 不等于已经完成直玩。
- 默认将直玩流程从广告管理器中解耦，使用一个持久化 `DouyinDirectPlayManager` 或同等职责组件。
- 不重复调用 `TT.InitSDK`。若项目已有 SDK 初始化器，等待它完成或订阅初始化事件。

## 标准工作流

### 1. 审计项目

运行：

```powershell
powershell -ExecutionPolicy Bypass -File <skill-dir>/scripts/audit_direct_play.ps1 -ProjectPath <unity-project>
```

随后重点阅读：TTSDK `package.json`/`ttsdk.xml`、SDK 初始化入口、首场景、关卡加载、存档、计时、暂停、登录、弹窗和 active 上报。

若入口包含配音、字幕或带声音的视频，同时使用全局 `unity-voiceover-subtitle-sync-diagnosis` Skill，并完整阅读其 `references/douyin-direct-play-voiceover.md`。资源加载、`VideoPlayer.Prepare()` 和画面就绪可发生在隐藏预加载，但任何可听播放、字幕时间轴和自动试玩都必须由首次直玩 `OnShow` 放行。

### 2. 判断接入类型

- **获客版**：`feed_game_channel=2`、`feed_game_scene=0`。核心是读取入口、加载对应玩法、就绪上报和 Feed 生命周期。
- **复访版**：以全场景订阅为主链，处理场景 1/2/3 的默认就绪写入、复访启动路由和可能的服务端 SPI。订阅、场景就绪写入、复访启动路由仍是不同 API，但采用“申请后直接默认就绪”时不再等待离线收益、体力或重要事件等业务条件。
- 用户只要求获客版时，不强行接入复访 API。

### 3. 建立生命周期状态机

先画出两条事件轴，禁止把它们合并：

```text
卡片轴：隐藏预启动 --OnShow--> 划到卡片/卡片可见 --OnHide--> 卡片划走/不可见
进入轴：卡片内直玩 --FeedEnter--> 用户进入完整小游戏 --FeedExit--> 用户退出完整小游戏回推荐流
```

严格遵守：

- `OnShow`/`OnHide` 负责卡片是否可见；`FeedEnter`/`FeedExit` 负责是否进入或退出完整小游戏。`FeedEnter` 不是“划到卡片”，`FeedExit` 也不是普通“划走卡片”。
- 隐藏预启动是潜在曝光：只准备场景、资源、UI 和输入，不播放配音/字幕、不启动 AI/剧情/关卡计时，不提交正式存档、不扣体力、不强制登录、不上报真实 active。
- `TT.ReportScene(sceneId=7001)` 在核心玩法可交互且已渲染后调用，并且每次启动最多一次。
- 第一次直玩 `OnShow` 才启动或恢复卡片内的 AI、动画、配音、字幕和试玩计时；`OnHide` 立即暂停这些卡片体验，下一次 `OnShow` 从正确进度恢复。
- 第一次 `FeedEnter` 才确认用户点击进入完整小游戏，可静默注册/登录、上报真实 active、提交会话，并按产品配置继承卡片内进度或转换到正式流程；不要在这里重新定义“卡片开始播放”。
- `FeedExit` 表示离开完整小游戏回到推荐流。先暂停完整游戏，再依据实际 `OnShow`/`OnHide` 状态决定是否恢复卡片；不要收到 `FeedExit` 就无条件播放卡片内容。
- `OnShow`/`OnHide` 也可能用于普通前后台切换，只有已确认是推荐流直玩上下文且尚未处于完整游戏时，才将其解释为卡片可见性。所有回调必须幂等，并容忍重复或紧邻到达。
- 保存监听委托，并在销毁时调用 `TT.OffFeedStatusChange`。

获客与复访共用上述事件语义，区别只在入口数据和进入后的业务：

- 获客：`feed_game_channel=2`、`feed_game_scene=0`，`OnShow` 播放获客试玩，`FeedEnter` 进入完整游戏并执行显式配置的承接策略。
- 复访：`feed_game_channel=1`、场景通常为 1/2/3，`OnShow` 展示对应复访内容，`FeedEnter` 进入完整游戏并承接复访状态。`StoreFeedData`/`GetFeedData` 是复访数据能力，不是可见性或进入事件。

### 3.1 复访订阅、就绪与加载必须分链

涉及复访时完整阅读 `references/revisit-subscription-readiness.md`，并分别保留状态和日志：

```text
全场景订阅（主链）：CheckFeedSubscribeStatus / RequestFeedSubscribe(type=play, allScene=true)
默认就绪写入：已订阅或发起全场景申请 -> Scene 1/2/3 分别 StoreFeedData(Status=1)
排障回读（可选）：需要确认平台数据时调用 GetFeedData
复访加载：启动参数 channel=1 + scene=1/2/3 + content_id -> 路由并加载对应内容
```

- `OnFeedStatusChange` 只处理进入/退出推荐流，不查询订阅、不写入就绪数据。
- 全场景订阅是当前工作流的主链。查询确认已订阅，或本次已经发起全场景申请后，直接为 Scene 1/2/3 写入默认就绪；不要再判断体力是否满、是否产生离线收益或是否发生重要事件。
- 订阅申请和 `StoreFeedData` 是不同 API；“申请后直接默认就绪”表示申请路径立即触发三场景写入，不表示订阅接口会自动替项目写入。平台仍提示“不存在相关就绪数据”时检查实际 Store 参数和回包，不要重复弹订阅。
- 订阅状态回包在不同 SDK/封装中可能使用 `subscribed`、`status` 或 `success`；记录完整原始回包并做类型安全兼容。这里的订阅 `status` 不得与 `GetFeedData` 的场景就绪 `status` 混为一个字段语义。
- 每次游戏启动最多尝试一次订阅弹窗。只由普通游戏正式胜利/失败结算等真实玩家手势触发；AI 卡片试玩、隐藏预加载和教学结算不得抢先消耗机会。
- 已订阅或已经发起全场景申请后立即刷新复访默认就绪数据。`GetFeedData` 只用于调试、平台排障或用户明确要求的验收，不作为业务放行、路由或加载复访场景的前置条件。

### 4. 设计多入口路由

不要使用 `feed_game_scene` 区分获客第 10/20/30 关，因为获客场景通常均为 0。

按以下优先级解析：

1. `feed_game_extra` 中的白名单 `route`；
2. `feed_game_content_id` 到本地或远程配置的映射；
3. 安全默认入口。

使用可配置路由表：

```text
route/content_id -> previewLevel -> commitProgress -> completeAction -> normalStartLevel
```

通关策略必须显式配置：继续下一关、从正式第 1 关开始、返回原存档、进入主菜单。不要默认把新玩家永久跳到高等级关卡。

### 5. 与现有游戏流程集成

```text
普通启动 -> 原 Boot/菜单/选关流程
直玩启动 -> 绕过开始页和选关页 -> 加载指定关卡
```

要求关卡加载 API 支持 `startCountdown=false`、`saveProgress=false` 和 `onReady` 回调。在资源、UI、输入都准备完成并至少渲染一帧后调用 `ReportScene`。第一次 `FeedEnter` 后再启动完整游戏的正式业务。

卡片内自动试玩、配音和字幕应在第一次直玩 `OnShow` 后开始；正式注册、真实 active 和完整游戏承接仍放在第一次 `FeedEnter`。这两处“开始”属于不同业务阶段。

`SchemePrepared`、资源加载完成、`VideoPlayer.prepareCompleted`、首帧 `Ready`、`ReportScene` 及其成功/完成回调都只能更新“已准备”状态，不得直接调用有声 `Play()` 或启动字幕。配音和首条字幕必须由同一个卡片可见启动方法在 `OnShow` 之后放行，避免一方抢跑。

### 6. 迁移现有 AdManager

若 `AdManagerImpl` 已含直玩代码：

- 保留唯一的 `TT.InitSDK` 所有者。
- 移除旧 `HandleLaunchScene` 自动调用，避免新旧管理器重复执行。
- 将启动参数、路由、ReportScene、Feed 监听迁移到直玩管理器。
- 广告、分享、加桌、侧边栏继续留在 AdManager。
- 获客预加载阶段禁止 `TT.Login(force:true)`、插屏、签到、订阅和真实激活上报。

### 7. 验证

至少验证：普通启动、两个不同入口、未知路由回退、隐藏预加载不播放/计时/保存/扣体力、首次 OnShow 启动卡片、OnHide/OnShow 暂停恢复、FeedEnter 不重播卡片、FeedExit 不误判为划走、ReportScene 仅一次、高关卡试玩完成策略；复访还要验证胜利/失败每次启动最多发起一次全场景订阅、申请路径直接执行三次默认 `StoreFeedData(Status=1)`、Scene 1/2/3 启动和对应内容加载。`GetFeedData` 仅在排障或明确要求时验证；最后完成编译、平台离线测试和风险检测。

## 资源

按需读取：

- `references/direct-play-reference.md`：官方概念、字段和 API 边界。
- `references/unity-implementation-pattern.md`：Unity 架构、状态机、多入口和关卡适配模板。
- `references/revisit-subscription-readiness.md`：复访全场景订阅、Scene 1/2/3 就绪写入/回读和启动加载闭环。
- `references/review-checklist.md`：代码审查与上线验收清单。
- `scripts/audit_direct_play.ps1`：扫描 Unity 项目的现有直玩接入情况。

## 输出要求

- 用中文说明判断、改动和风险。
- 引用具体绝对文件路径与行号。
- 在修改代码前指出唯一 SDK 初始化所有者和唯一 Feed 监听所有者。
- 用户仅咨询架构时给出映射和生命周期；用户要求实现时直接修改、编译并报告变更文件。
